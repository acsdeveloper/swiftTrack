(function() {
    'use strict';
    angular.module('swiftTrack.constants', [])
        .constant('Constants', {
            //'baseUrl': 'http://192.168.1.124:3030/', // COMMON SERVER
            //'baseUrl': 'http://localhost:3030/' // COMMON SERVER
            'baseUrl': 'https://swifttrack-agilexcyber.c9users.io', // COMMON SERVER
            'productionServer': true
        });
}());

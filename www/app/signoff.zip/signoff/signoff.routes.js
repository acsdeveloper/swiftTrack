(function() {
    'use strict';

    angular.module('swiftTrack.signoffpage', ['ui.router'])
        .config(['$stateProvider', function($stateProvider) {
            $stateProvider
                // .state('app.progressreport', {
                //     url: '/report',
                //     cache: false,
                //     views: {
                //         'menuContent': {
                //             templateUrl: 'app/people/people.html',
                //             controller: 'peopleCtrl',
                //             controllerAs: 'vm',
                //         }
                //     }
                // });
                .state('signoffpage', {
                    url: '/signoff',
                    templateUrl: 'app/people/signoff.html',
                    controller: 'signoffCtrl',
                    controllerAs: 'vm',
                    cache: false,
                    
                })
        }])


}())
